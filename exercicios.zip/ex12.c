#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void)
{
    FILE *arq;
    char nome[10], str[10];
    int dia, mes, ano;
    arq = fopen("arquivo.txt", "wt");
    do
    {
        printf("nome? ");
        fgets(nome, 10, stdin);
        nome[strlen(nome) - 1] = 0;
        if (nome[0])
        {
            printf("dia? ");
            fgets(str, 10, stdin);
            dia = atoi(str);
            printf("mes? ");
            fgets(str, 10, stdin);
            mes = atoi(str);
            printf("ano? ");
            fgets(str, 10, stdin);
            ano = atoi(str);
            fprintf(arq, "%s %d %d %d\n", nome, dia, mes, ano);
        }
    } while (nome[0]);
    fclose(arq);
    return 0;
}
