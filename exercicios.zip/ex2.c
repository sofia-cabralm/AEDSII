#include <stdio.h>

int main()
{
    int vetor[9] = {3, 7, 2, 4, 5, 8, 6, 10, 9};
    int tmp, n = 9, posmenor, K;
    scanf("%d", &K);
    for (int i = 0; i < K; i++)
    {
        posmenor = i;
        for (int j = i + 1; j < n; j++)
            if (vetor[j] < vetor[posmenor])
                posmenor = j;
        tmp = vetor[i];
        vetor[i] = vetor[posmenor];
        vetor[posmenor] = tmp;
    }
    for (int i = 0; i < K; i++)
        printf("%d ", vetor[i]);
    puts("");
    return 0;
}