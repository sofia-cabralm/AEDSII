#include <stdio.h>

void figura(int n)
{
    for (int i = n - 1, k = 1; i > 0; i--, k += 2)
    {
        for (int j = 0; j < i; j++)
            printf(".");
        for (int j = 0; j < k; j++)
            printf("*");
        for (int j = 0; j < i; j++)
            printf(".");
        printf("\n");
    }
    for (int i = 0; i < 2 * n - 1; i++)
        printf("*");
    printf("\n");
    for (int i = 1, k = 2 * n - 3; i < n; i++, k -= 2)
    {
        for (int j = 0; j < i; j++)
            printf(".");
        for (int j = 0; j < k; j++)
            printf("*");
        for (int j = 0; j < i; j++)
            printf(".");
        printf("\n");
    }
}

int main(void)
{
    figura(3);
    return 0;
}
