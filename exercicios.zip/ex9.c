#include <stdio.h>

int maior(int a, int b, int c)
{
    if (a > b && a > c)
        return a;
    else if (b > c)
        return b;
    else
        return c;
}

int main(int argc, char const *argv[])
{
    printf("%d\n", maior(10, 20, 5));
    printf("%d\n", maior(2, 2, 2));
    return 0;
}
