#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[])
{
    struct veiculo
    {
        char proprietario[30];
        int combustivel;
        char modelo[20];
        char cor[20];
        char placa[7];
    } tabela[100];
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%s %d %s %s %s\n", &tabela[i].proprietario, &tabela[i].combustivel,
              &tabela[i].modelo, &tabela[i].cor, &tabela[i].placa);
    for (int i = 0; i < n; i++)
        if (!strcmp(tabela[i].cor, "branca"))
            printf("placa = %s\n", tabela[i].placa);
    return 0;
}
