#include <stdio.h>
#include <ctype.h>

void maiuscula(char *s)
{
    for (int i = 0; s[i]; i++)
        s[i] = toupper(s[i]);
}

int main(int argc, char const *argv[])
{
    char nome[20] = "Luiz Eduardo";
    maiuscula(nome);
    puts(nome);
    return 0;
}
