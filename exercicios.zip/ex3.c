#include <stdio.h>
#define N 100

int main(int argc, char const *argv[])
{
    int matriz[N][N];
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            scanf("%d", &matriz[i][j]);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < i; j++)
        {
            int tmp = matriz[i][j];
            matriz[i][j] = matriz[j][i];
            matriz[j][i] = tmp;
        }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            printf("%4d", matriz[i][j]);
        printf("\n");
    }
    return 0;
}
