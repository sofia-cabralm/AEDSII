#include <stdio.h>

int soma(int n, int *v)
{
    int s = 0;
    for (int i = 0; i < n; i++)
        s = s + v[i];
    return s;
}

int main(int argc, char const *argv[])
{
    int vetor[5] = {10, 20, 30, 40, 50};
    int a[10] = {1, 2, 3, 2, 3, 4, 5, 6, 7, 2};
    printf("%d\n", soma(5, vetor));
    printf("%d\n", soma(10, a));
    return 0;
}
