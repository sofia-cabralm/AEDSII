#include <stdio.h>
#include <string.h>

int main(int argc, char const *argv[])
{
    FILE *arq;
    char nome[10], str[10];
    int dia, mes, ano;
    arq = fopen("arquivo.txt", "rt");
    do
    {
        fscanf(arq, "%s %d %d %d\n", nome, &dia, &mes, &ano);
        printf("%s tem %d anos\n", nome, 2023 - ano);
    } while (!feof(arq));
    fclose(arq);
    return 0;
}
